import React from "react";
import BookCover from "./BookCover.jsx";

/* Vista a griglia: 3 colonne, solo copertine. Il tocco apre il menu azioni. */
export default function BookGrid({ books, onOpen }) {
  return (
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"0.8rem 0.6rem"}}>
      {books.map(b=>(
        <div key={b.id} style={{position:"relative",aspectRatio:"2 / 3"}}>
          <button onClick={()=>onOpen(b)} aria-label={b.title}
            style={{position:"absolute",inset:0,display:"block",width:"100%",height:"100%",
              padding:0,border:"none",background:"none",cursor:"pointer"}}>
            <BookCover book={b}/>
          </button>
          {b.favorite&&(
            <span style={{position:"absolute",top:4,right:4,width:20,height:20,borderRadius:"50%",
              background:"rgba(28,22,17,0.7)",color:"var(--amber)",fontSize:"0.7rem",
              display:"flex",alignItems:"center",justifyContent:"center",pointerEvents:"none"}}>★</span>
          )}
        </div>
      ))}
    </div>
  );
}
