import React, { useState, useEffect } from "react";
import { bookColor } from "../lib/helpers.js";

/* Copertina Open Library; se manca o non si carica (es. offline, non ancora in cache)
   resta il riquadro nel colore del libro. Riempie il contenitore del chiamante. */
export default function BookCover({ book, radius = 8, label = true }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [book.cover]);
  const show = book.cover && !failed;
  return (
    <div style={{width:"100%",height:"100%",borderRadius:radius,overflow:"hidden",
      background:bookColor(book),boxShadow:"0 1px 4px rgba(28,22,17,0.18)"}}>
      {show
        ?<img src={book.cover} alt={book.title} loading="lazy" decoding="async"
            onError={()=>setFailed(true)}
            style={{width:"100%",height:"100%",objectFit:"cover",display:"block"}}/>
        :<div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",
            padding:"0.4rem",boxSizing:"border-box",color:"#fff",textAlign:"center",
            fontFamily:"'Playfair Display',serif",fontWeight:700,lineHeight:1.2,
            fontSize:label?"0.78rem":"1.3rem",wordBreak:"break-word",overflow:"hidden"}}>
          <span style={label?{display:"-webkit-box",WebkitLineClamp:5,WebkitBoxOrient:"vertical",overflow:"hidden"}:undefined}>
            {label?book.title:book.title.charAt(0).toUpperCase()}
          </span>
        </div>}
    </div>
  );
}
