import React, { useContext } from "react";
import { STATUS } from "../lib/constants.js";
import { BookActions } from "../lib/actions.js";
import BookCover from "./BookCover.jsx";

/* Foglio azioni per la vista a griglia: stesse voci del menu ⋮ della card. */
export default function BookActionSheet({ book, onClose, onEdit, onDelete, onToggleFavorite }) {
  const { toggleRead, abandon } = useContext(BookActions);
  const items = [["Modifica", () => onEdit(book)]];
  if (book.status === STATUS.READING || book.status === STATUS.READ)
    items.push([book.status === STATUS.READING ? "✓ Segna come letto" : "↩ Rimuovi dai letti", () => toggleRead(book.id)]);
  if (book.status === STATUS.READING) items.push(["Abbandona", () => abandon(book.id)]);
  if (book.status === STATUS.READ)
    items.push([book.favorite ? "☆ Rimuovi dai preferiti" : "★ Aggiungi ai preferiti", () => onToggleFavorite(book.id)]);
  items.push(["Elimina", () => onDelete(book.id), true]);

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",gap:"0.85rem",margin:"0.25rem 0 1rem"}}>
        <div style={{width:44,height:66,flexShrink:0}}><BookCover book={book} radius={6} label={false}/></div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:"1.1rem",lineHeight:1.25,color:"var(--ink)"}}>{book.title}</div>
          <div style={{fontSize:"0.82rem",color:"var(--muted)",marginTop:"0.15rem"}}>{book.author}</div>
        </div>
        <button onClick={onClose} style={{background:"none",border:"none",cursor:"pointer",
          color:"var(--muted)",fontSize:"1.3rem",lineHeight:1,padding:"0.2rem",alignSelf:"flex-start"}}>✕</button>
      </div>
      <div style={{background:"var(--card-bg)",borderRadius:14,overflow:"hidden",boxShadow:"0 1px 4px rgba(28,22,17,0.07)"}}>
        {items.map(([label, fn, danger], i) => (
          <button key={label} onClick={() => { onClose(); fn(); }} style={{
            display:"block",width:"100%",padding:"0.9rem 1rem",background:"none",border:"none",
            borderTop:i?"1px solid var(--border)":"none",cursor:"pointer",textAlign:"left",
            fontFamily:"'Lora',serif",fontSize:"0.95rem",color:danger?"#d32f2f":"var(--ink)"}}>{label}</button>
        ))}
      </div>
    </div>
  );
}
