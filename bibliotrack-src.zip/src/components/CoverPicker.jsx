import React, { useState, useEffect } from "react";
import { inputStyle } from "../lib/styles.js";
import { coverUrl } from "../lib/helpers.js";

/* Ricerca copertine su Open Library per titolo e autore; si tocca quella giusta. */
export default function CoverPicker({ initialQuery, onPick, onClose }) {
  const [query, setQuery] = useState(initialQuery || "");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState(false);

  async function search(e) {
    if (e) e.preventDefault();
    if (!query.trim()) return;
    setLoading(true); setError(false);
    try {
      const r = await fetch(`https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&limit=24&fields=key,title,author_name,cover_i`);
      const data = await r.json();
      const seen = new Set();
      setResults((data.docs || []).filter(d => d.cover_i && !seen.has(d.cover_i) && seen.add(d.cover_i))
        .map(d => ({ id: d.cover_i, title: d.title || "", author: (d.author_name || [])[0] || "" })));
    } catch { setResults([]); setError(true); }
    finally { setLoading(false); setDone(true); }
  }
  useEffect(() => { if (query.trim()) search(); }, []); // eslint-disable-line

  return (
    <div style={{background:"var(--card-bg)",border:"1px solid var(--border)",borderRadius:14,padding:"0.85rem",marginTop:"0.75rem"}}>
      <form onSubmit={search} style={{display:"flex",gap:"0.5rem",marginBottom:"0.75rem"}}>
        <input style={{...inputStyle,padding:"0.65rem 0.85rem",fontSize:"0.88rem"}} type="text"
          placeholder="Titolo e autore" value={query} onChange={e=>setQuery(e.target.value)}/>
        <button type="submit" disabled={loading} style={{padding:"0 1rem",background:"var(--burgundy)",color:"#fff",
          border:"none",borderRadius:12,cursor:"pointer",fontFamily:"'Lora',serif",fontWeight:600,opacity:loading?0.7:1}}>
          {loading?"…":"Cerca"}
        </button>
      </form>
      {error&&<div style={{textAlign:"center",color:"var(--burgundy)",fontSize:"0.82rem",padding:"0.5rem"}}>
        Impossibile contattare Open Library. Controlla la connessione e riprova.</div>}
      {done&&!error&&results.length===0&&<div style={{textAlign:"center",color:"var(--muted)",fontStyle:"italic",fontSize:"0.85rem",padding:"0.5rem"}}>
        Nessuna copertina trovata. Prova a cambiare la ricerca.</div>}
      {results.length>0&&(
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"0.6rem",maxHeight:300,overflowY:"auto"}}>
          {results.map(r=>(
            <button key={r.id} onClick={()=>onPick(coverUrl(r.id))} style={{background:"none",border:"none",padding:0,cursor:"pointer",textAlign:"left"}}>
              <img src={coverUrl(r.id)} alt={r.title} loading="lazy"
                style={{width:"100%",aspectRatio:"2 / 3",objectFit:"cover",borderRadius:6,display:"block",
                  background:"var(--parchment)",boxShadow:"0 1px 3px rgba(28,22,17,0.2)"}}/>
              <div style={{fontSize:"0.65rem",color:"var(--muted)",marginTop:"0.25rem",lineHeight:1.25,
                display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical",overflow:"hidden"}}>{r.title}</div>
            </button>
          ))}
        </div>
      )}
      <button onClick={onClose} style={{width:"100%",marginTop:"0.75rem",padding:"0.6rem",background:"none",
        border:"1.5px solid var(--border)",borderRadius:12,cursor:"pointer",fontFamily:"'Lora',serif",
        fontSize:"0.85rem",color:"var(--muted)"}}>Chiudi</button>
    </div>
  );
}
